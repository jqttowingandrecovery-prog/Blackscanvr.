BLACKSCAN VR — UNITY STARTER PROJECT
Target: Meta Quest 3 / Quest 3S

This ZIP contains a Unity starter project with a black-view controller and a sparse white-point visual prototype. It is not an APK.

IMPORTANT: The included points are procedural placeholder geometry, not your actual room scan. To display real room geometry, integrate Meta XR SDK + MR Utility Kit (MRUK), configure Scene/Spatial Data permissions, and replace the procedural point generator with points sampled from the room mesh.

You need a computer with Unity Hub and Android Build Support (SDK/NDK/OpenJDK) to build the APK. See BUILD_GUIDE.md.
