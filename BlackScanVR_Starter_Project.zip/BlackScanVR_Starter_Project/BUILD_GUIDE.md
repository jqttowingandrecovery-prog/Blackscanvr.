# Build guide

1. Open this folder in Unity Hub. This is a starter folder; Unity may create additional project settings when opened.
2. Install Android Build Support, Android SDK & NDK Tools, and OpenJDK through Unity Hub.
3. Install/configure Meta XR All-in-One SDK and OpenXR using Meta's current Quest setup instructions.
4. Create a scene with your XR Origin / Meta camera rig.
5. Add an empty GameObject named `BlackScan`; add `BlackoutController` and `SparsePointCloud`.
6. Assign the active XR camera to `BlackoutController` if Camera.main does not find it.
7. Tune `pointCount`, `roomRadius`, `roomHeight`, and `pointSize` in the Inspector.
8. Build Settings / Build Profiles: select Android, configure the package identifier, then build an APK.

Real room geometry integration:
- This starter does NOT yet query the Quest room mesh.
- Add Meta XR SDK + MRUK, enable the appropriate Scene/Spatial Data permissions and user permission flow, then sample points from the room anchors/mesh available in your SDK version.
- Replace `SparsePointCloud.GeneratePoints()` with those sampled points. Handle permission denial and unavailable room data.

Troubleshooting:
- Black view: check the XR rig and camera are active.
- Points too dense: reduce Point Count or Point Size.
- Build errors: use Unity and Meta XR SDK versions listed as compatible by Meta.
