using UnityEngine;

/// <summary>
/// Procedural point-cloud visual placeholder. These are NOT real room-scan points.
/// Replace GeneratePoints() with points sampled from Meta MRUK room geometry.
/// </summary>
[RequireComponent(typeof(ParticleSystem))]
public class SparsePointCloud : MonoBehaviour
{
    [Range(100, 20000)] public int pointCount = 1800;
    [Min(1f)] public float roomRadius = 3f;
    [Min(1f)] public float roomHeight = 2.5f;
    [Min(0.001f)] public float pointSize = 0.012f;
    public bool showFloor = true;
    public bool showCeiling = true;
    public bool showWalls = true;

    ParticleSystem ps;
    ParticleSystem.Particle[] points;

    void Start()
    {
        ps = GetComponent<ParticleSystem>();
        var main = ps.main;
        main.loop = false;
        main.playOnAwake = false;
        main.maxParticles = pointCount;
        main.simulationSpace = ParticleSystemSimulationSpace.World;
        main.startSpeed = 0f;
        main.startLifetime = Mathf.Infinity;
        main.startSize = pointSize;
        main.startColor = Color.white;

        var emission = ps.emission;
        emission.enabled = false;

        var renderer = GetComponent<ParticleSystemRenderer>();
        renderer.renderMode = ParticleSystemRenderMode.Billboard;
        renderer.material = new Material(Shader.Find("Particles/Standard Unlit"));
        renderer.material.color = Color.white;
        renderer.shadowCastingMode = UnityEngine.Rendering.ShadowCastingMode.Off;
        renderer.receiveShadows = false;

        GeneratePoints();
    }

    void GeneratePoints()
    {
        points = new ParticleSystem.Particle[Mathf.Max(1, pointCount)];
        for (int i = 0; i < points.Length; i++)
        {
            Vector3 p = SamplePlaceholderSurface();
            var particle = new ParticleSystem.Particle();
            particle.position = transform.TransformPoint(p);
            particle.startColor = Color.white;
            particle.startSize = pointSize * Random.Range(0.65f, 1.25f);
            particle.startLifetime = Mathf.Infinity;
            particle.remainingLifetime = Mathf.Infinity;
            points[i] = particle;
        }
        ps.SetParticles(points, points.Length);
        ps.Play();
    }

    Vector3 SamplePlaceholderSurface()
    {
        int n = (showFloor ? 1 : 0) + (showCeiling ? 1 : 0) + (showWalls ? 4 : 0);
        if (n == 0) n = 1;
        int choice = Random.Range(0, n);
        float h = Random.Range(0f, roomHeight);
        float r = roomRadius;

        if (showFloor && choice == 0)
            return new Vector3(Random.Range(-r, r), 0f, Random.Range(-r, r));

        if (showFloor) choice--;
        if (showCeiling && choice == 0)
            return new Vector3(Random.Range(-r, r), roomHeight, Random.Range(-r, r));

        switch (Random.Range(0, 4))
        {
            case 0: return new Vector3(-r, h, Random.Range(-r, r));
            case 1: return new Vector3(r, h, Random.Range(-r, r));
            case 2: return new Vector3(Random.Range(-r, r), h, -r);
            default: return new Vector3(Random.Range(-r, r), h, r);
        }
    }
}
