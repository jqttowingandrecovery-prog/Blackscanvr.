using UnityEngine;

public class BlackoutController : MonoBehaviour
{
    [Tooltip("Assign the camera used by your XR rig; otherwise Camera.main is used.")]
    public Camera targetCamera;
    public bool blackAmbientLighting = true;
    Color oldAmbient;
    UnityEngine.Rendering.AmbientMode oldMode;

    void Awake()
    {
        if (targetCamera == null) targetCamera = Camera.main;
        oldAmbient = RenderSettings.ambientLight;
        oldMode = RenderSettings.ambientMode;

        if (targetCamera != null)
        {
            targetCamera.clearFlags = CameraClearFlags.SolidColor;
            targetCamera.backgroundColor = Color.black;
        }

        if (blackAmbientLighting)
        {
            RenderSettings.ambientMode = UnityEngine.Rendering.AmbientMode.Flat;
            RenderSettings.ambientLight = Color.black;
            RenderSettings.reflectionIntensity = 0f;
        }
    }

    void OnDestroy()
    {
        RenderSettings.ambientLight = oldAmbient;
        RenderSettings.ambientMode = oldMode;
    }
}
